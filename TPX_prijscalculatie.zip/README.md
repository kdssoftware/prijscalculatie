usage: 

form hook : `[TPX_prijscalculatie_form]`