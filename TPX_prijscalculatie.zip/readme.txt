=== TPX prijscalculatie ===
Contributors: snakehead007
Donate link: https://paypal.me/KarelDeSmet
Tags: TPX, pricing, quotations
Tested up to: 5.7.2
Stable tag: 5.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
A plugin that adds a new TPX pricing system, using activities, packets and workshops.
 
== Description ==
 
A plugin that adds a new TPX pricing system, using activities, packets and workshops.
 
== Installation ==
 
use the hook '[TPX_prijscalculatie_form]' on any page to add the form to the page.
 
== Frequently Asked Questions ==
 
= Do you have any questions? =
 
Message me at snakehead007@pm.me
 
 
== Screenshots ==
 
== Changelog ==
 
= 1.0.0 =
* intial release

== Upgrade Notice ==
 
 
== Arbitrary section ==